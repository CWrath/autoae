# Auto AE for macOS

`build_macos_autoae.py` turns this folder into a Mac app. It runs on Windows or a Mac:

```
python build_macos_autoae.py
```

That makes `dist/Auto AE.app` and `dist/AutoAE-macos.zip`. Copy the zip to the Mac, double-click it,
and drag **Auto AE** into Applications. Rebuild whenever you change a tool.

## What the Mac needs

- **Python 3.10 or newer with Tk.** Either the installer from python.org (Tk included), or Homebrew:
  `brew install python@3.13 python-tk@3.13`. If there isn't one, the app says so and links to python.org.
- **FFmpeg** for Proxy Generator, File Converter and Media Browser: `brew install ffmpeg`.
  The app also looks in `/opt/homebrew/bin` and `/usr/local/bin`, or you can put `ffmpeg` and `ffprobe`
  in an `ffmpeg-mac` folder here before building.
- An internet connection the first time it opens.

## First launch

The app isn't signed by Apple, so macOS blocks it the first time. Either:

- Open it once, then go to **System Settings → Privacy & Security** and click **Open Anyway**, or
- run this in Terminal: `xattr -dr com.apple.quarantine "/Applications/Auto AE.app"`

A setup window then installs the Python packages listed in `requirements-macos.txt` (a few minutes).
After that it opens straight away. Setup runs again only when that list or the Python version changes.

## Where things live on the Mac

Everything is in `~/Library/Application Support/AUTO_AE` (in Finder: Go → Go to Folder…):

| | |
|---|---|
| `app/` | The copy of the code the app runs. Tools save their settings here too. |
| `venv/` | The Python packages. Delete this folder to force a clean setup. |
| `autoae.log` | Output from the last run. Check here if a tool misbehaves. |
| `setup.log`, `launcher.log` | Details of the package install and which Python was used. |

Opening a newer build replaces the code in `app/` but keeps the settings your tools saved there,
and folder templates you edited are never overwritten.

## Checking for updates

Use **Check for Updates** in the app's bottom bar. Auto AE checks the latest stable release in
`CWrath/autoae` and asks before downloading or installing it. Windows opens the release installer;
macOS stages the new app code in Application Support, then closes and reopens Auto AE. Your saved
settings are kept.

To publish an update, set `APP_VERSION` in `app_version.py`, build the Windows installer with
`build_windows_exe.py`, and build the macOS app with `build_macos_autoae.py`. Create a GitHub
release in `CWrath/autoae` using the matching `vMAJOR.MINOR.PATCH` tag, and attach the exact assets
`AutoAE-Setup.exe` and `AutoAE-macos.zip`. Both assets must be attached for an update to be offered
on both platforms. Older installations that predate the update checker need to be updated once
manually; later releases can be installed from the app.

## Files in this folder

| File | What it does |
|---|---|
| `launcher.sh` | Becomes `Auto AE.app/Contents/MacOS/AutoAE`. Finds a Python with Tk and starts `bootstrap.py`. |
| `bootstrap.py` | Copies the code to Application Support, installs the packages, starts `main.py`, and shows an error if it can't. |
| `requirements-macos.txt` | Packages for the Mac. The ones under `# --- optional ---` are installed one at a time, so a failure there only affects the tool that uses them. |
| `AppIcon.icns` | The app icon. |

To use a specific Python, open the app from Terminal with
`AUTOAE_PYTHON=/path/to/python3 "/Applications/Auto AE.app/Contents/MacOS/AutoAE"`.

The menu bar shows "Python" rather than "Auto AE" because the app runs on your installed Python.
