#!/usr/bin/env python3
"""Build the macOS version of Auto AE: dist/Auto AE.app and dist/AutoAE-macos.zip.

    python build_macos_autoae.py

Runs on Windows or a Mac with the standard library only. Copy the zip to the Mac,
double-click it, and drag "Auto AE.app" into Applications. The app runs on the Mac's
own Python 3 (python.org, or Homebrew with python-tk), and its first launch installs
the packages in macos/requirements-macos.txt. See macos/README.md.

Rebuild after changing any tool; opening the new app on the Mac updates its copy of
the code and keeps the settings the tools have saved.
"""

import hashlib
import json
import plistlib
import shutil
import stat
import sys
import time
import zipfile
from datetime import datetime
from pathlib import Path

from app_version import APP_VERSION

ROOT = Path(__file__).resolve().parent
MAC = ROOT / "macos"
DIST = ROOT / "dist"
APP_NAME = "Auto AE"
EXECUTABLE = "AutoAE"
BUNDLE_ID = "com.autoae.app"
VERSION = APP_VERSION

# What goes into the app. Everything else in this folder (venvs, backups, the Windows
# FFmpeg build, saved settings) stays behind.
APP_FILES = ["main.py", "theme.py", "base_tool.py", "tool_loader.py", "tool_template.py",
             "app_updater.py", "app_version.py",
             "ffmpeg_setup.py", "error_help.py", "taskboard_core.py", "autoae_theme.json", "UI_THEME_GUIDE.md"]
APP_GLOBS = [("tools", "*.py"), ("assets", "**/*"), ("foldertemplates", "*.csv"), ("ffmpeg-mac", "*")]
SEED_DIRS = ("foldertemplates",)   # starter files: added on the Mac only if missing, never overwritten
EXECUTABLE_DIRS = ("ffmpeg-mac",)  # optional ffmpeg/ffprobe for Mac, dropped in by you


def collect_app_files():
    files = [name for name in APP_FILES if (ROOT / name).is_file()]
    missing = [name for name in APP_FILES if name not in files]
    if missing:
        raise SystemExit("Missing from {}: {}".format(ROOT, ", ".join(missing)))
    for folder, pattern in APP_GLOBS:
        base = ROOT / folder
        if not base.is_dir():
            continue
        for path in sorted(base.glob(pattern)):
            rel = path.relative_to(ROOT)
            if path.is_file() and "__pycache__" not in rel.parts and not any(p.startswith(".") for p in rel.parts):
                files.append(rel.as_posix())
    return files


def read_text_lf(path):
    """Scripts must have Unix line endings on the Mac, whatever this folder uses."""
    return path.read_bytes().replace(b"\r\n", b"\n")


def build_app(app_dir):
    if app_dir.exists():
        shutil.rmtree(app_dir)
    contents = app_dir / "Contents"
    resources = contents / "Resources"
    (contents / "MacOS").mkdir(parents=True)
    (resources / "app").mkdir(parents=True)

    files = collect_app_files()
    manifest = {"files": {}, "seed": [], "executable": []}
    for rel in files:
        source, target = ROOT / rel, resources / "app" / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        manifest["files"][rel] = hashlib.sha256(target.read_bytes()).hexdigest()
        if rel.split("/")[0] in SEED_DIRS:
            manifest["seed"].append(rel)
        if rel.split("/")[0] in EXECUTABLE_DIRS:
            manifest["executable"].append(rel)
    fingerprint = hashlib.sha256(json.dumps(manifest["files"], sort_keys=True).encode()).hexdigest()
    manifest["build"] = fingerprint[:16]
    manifest["version"] = VERSION
    manifest["built"] = datetime.now().isoformat(timespec="seconds")
    (resources / "app-manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    (contents / "MacOS" / EXECUTABLE).write_bytes(read_text_lf(MAC / "launcher.sh"))
    (resources / "bootstrap.py").write_bytes(read_text_lf(MAC / "bootstrap.py"))
    (resources / "requirements-macos.txt").write_bytes(read_text_lf(MAC / "requirements-macos.txt"))
    shutil.copyfile(MAC / "AppIcon.icns", resources / "AppIcon.icns")

    info = {
        "CFBundleDevelopmentRegion": "en",
        "CFBundleDisplayName": APP_NAME,
        "CFBundleExecutable": EXECUTABLE,
        "CFBundleIconFile": "AppIcon",
        "CFBundleIdentifier": BUNDLE_ID,
        "CFBundleInfoDictionaryVersion": "6.0",
        "CFBundleName": APP_NAME,
        "CFBundlePackageType": "APPL",
        "CFBundleShortVersionString": VERSION,
        "CFBundleVersion": datetime.now().strftime("%Y%m%d.%H%M"),
        "LSApplicationCategoryType": "public.app-category.video",
        "LSMinimumSystemVersion": "11.0",
        "NSHighResolutionCapable": True,
        "NSHumanReadableCopyright": "Auto AE",
    }
    with open(contents / "Info.plist", "wb") as handle:
        plistlib.dump(info, handle)
    (contents / "PkgInfo").write_text("APPL????", encoding="ascii")

    if sys.platform != "win32":
        for path in [contents / "MacOS" / EXECUTABLE] + [resources / "app" / rel for rel in manifest["executable"]]:
            path.chmod(0o755)
    return manifest


def is_executable(rel_in_bundle):
    parts = rel_in_bundle.split("/")
    if parts[-2:] == ["MacOS", EXECUTABLE]:
        return True
    return "app" in parts and parts[parts.index("app") + 1:][:1] == [EXECUTABLE_DIRS[0]]


def build_zip(app_dir, zip_path):
    """Zip the app with Unix permissions set, so the launcher stays executable even when built on Windows."""
    if zip_path.exists():
        zip_path.unlink()
    now = time.localtime()[:6]
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted([app_dir] + list(app_dir.rglob("*"))):
            name = path.relative_to(app_dir.parent).as_posix()
            if path.is_dir():
                entry = zipfile.ZipInfo(name + "/", date_time=now)
                entry.external_attr = (stat.S_IFDIR | 0o755) << 16 | 0x10
                entry.create_system = 3
                archive.writestr(entry, b"")
            else:
                entry = zipfile.ZipInfo(name, date_time=now)
                mode = 0o755 if is_executable(name.split("/", 1)[1]) else 0o644
                entry.external_attr = (stat.S_IFREG | mode) << 16
                entry.create_system = 3
                entry.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(entry, path.read_bytes())


def main():
    DIST.mkdir(exist_ok=True)
    app_dir = DIST / "{}.app".format(APP_NAME)
    zip_path = DIST / "AutoAE-macos.zip"
    manifest = build_app(app_dir)
    build_zip(app_dir, zip_path)
    tools = sum(1 for rel in manifest["files"] if rel.startswith("tools/"))
    print("Built {} ({} tools, build {})".format(app_dir, tools, manifest["build"]))
    print("Zipped {} ({:.1f} MB)".format(zip_path, zip_path.stat().st_size / 1e6))
    print("On the Mac: unzip, drag Auto AE into Applications, then open it. See macos/README.md.")


if __name__ == "__main__":
    main()
