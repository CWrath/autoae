import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath

from app_version import APP_VERSION


REPOSITORY = "CWrath/autoae"
API_URL = "https://api.github.com/repos/{}/releases/latest".format(REPOSITORY)
ASSET_NAMES = {
    "win32": "AutoAE-Setup.exe",
    "darwin": "AutoAE-macos.zip",
}
MAX_RELEASE_SIZE = 2 * 1024 * 1024 * 1024
_VERSION_PATTERN = re.compile(r"^v?(\d+)\.(\d+)\.(\d+)$")


def _version_tuple(version):
    match = _VERSION_PATTERN.fullmatch(str(version).strip())
    if not match:
        raise ValueError("Version must use the format vMAJOR.MINOR.PATCH.")
    return tuple(int(part) for part in match.groups())


def check_for_update(current_version=APP_VERSION, system=None, opener=None):
    """Return the latest compatible release, or None when already up to date."""
    system = system or sys.platform
    asset_name = ASSET_NAMES.get(system)
    if not asset_name:
        raise RuntimeError("Automatic updates are not supported on this platform.")

    request = urllib.request.Request(
        API_URL,
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": "AutoAE-Updater",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with (opener or urllib.request.urlopen)(request, timeout=30) as response:
            release = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise RuntimeError(
                "No published Auto AE release was found at github.com/{}.".format(REPOSITORY)
            ) from exc
        raise RuntimeError("GitHub update check failed (HTTP {}).".format(exc.code)) from exc
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        raise RuntimeError("Couldn't check GitHub for updates: {}".format(exc)) from exc

    tag = release.get("tag_name", "")
    try:
        latest_version = _version_tuple(tag)
        installed_version = _version_tuple(current_version)
    except ValueError as exc:
        raise RuntimeError("The latest GitHub release has an invalid version tag.") from exc

    if latest_version <= installed_version:
        return None

    assets = release.get("assets", [])
    asset = next((item for item in assets if item.get("name") == asset_name), None)
    if asset is None:
        raise RuntimeError(
            "Release {} is missing its required {} update file.".format(tag, asset_name)
        )
    if not isinstance(asset.get("size"), int) or not 0 < asset["size"] <= MAX_RELEASE_SIZE:
        raise RuntimeError("The release update file has an invalid or unsupported size.")

    asset_url = asset.get("browser_download_url", "")
    parsed_url = urllib.parse.urlparse(asset_url)
    if (parsed_url.scheme != "https" or parsed_url.hostname != "github.com"
            or not parsed_url.path.startswith("/{}/releases/download/".format(REPOSITORY))):
        raise RuntimeError("The release update file has an unexpected download URL.")

    return {
        "version": ".".join(str(part) for part in latest_version),
        "tag": tag,
        "name": release.get("name") or tag,
        "notes": release.get("body") or "",
        "release_url": release.get("html_url") or "",
        "asset_name": asset_name,
        "asset_url": asset_url,
        "asset_size": asset["size"],
    }


def download_release_asset(release, progress_callback=None, opener=None):
    """Download a release asset into a unique temporary folder; return its path."""
    parsed_url = urllib.parse.urlparse(release["asset_url"])
    expected_name = ASSET_NAMES.get(sys.platform)
    if release["asset_name"] != expected_name:
        raise RuntimeError("The selected update file does not match this platform.")
    if (parsed_url.scheme != "https" or parsed_url.hostname != "github.com"
            or not parsed_url.path.startswith("/{}/releases/download/".format(REPOSITORY))):
        raise RuntimeError("The release update file has an unexpected download URL.")

    request = urllib.request.Request(
        release["asset_url"], headers={"User-Agent": "AutoAE-Updater"}
    )
    folder = Path(tempfile.mkdtemp(prefix="autoae-update-"))
    target = folder / expected_name
    received = 0
    try:
        with (opener or urllib.request.urlopen)(request, timeout=60) as response, open(target, "wb") as output:
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                received += len(block)
                if received > release["asset_size"] or received > MAX_RELEASE_SIZE:
                    raise RuntimeError("The downloaded update is larger than the published file.")
                output.write(block)
                if progress_callback:
                    progress_callback(received, release["asset_size"])
        if received != release["asset_size"]:
            raise RuntimeError(
                "The downloaded update is incomplete ({} of {} bytes).".format(
                    received, release["asset_size"]
                )
            )
        return str(target)
    except Exception:
        shutil.rmtree(folder, ignore_errors=True)
        raise


def stage_macos_update(archive_path, support_dir, expected_version=None):
    """Validate and stage a new macOS app-code overlay without touching user settings."""
    support_dir = Path(support_dir).expanduser().resolve()
    update_dir = support_dir / "release-update"
    staging_dir = support_dir / "release-update-staging"
    previous_dir = support_dir / "release-update-previous"

    if staging_dir.exists():
        shutil.rmtree(staging_dir)
    staging_dir.mkdir(parents=True)

    try:
        with zipfile.ZipFile(archive_path) as archive:
            members = archive.infolist()
            prefix = "Auto AE.app/Contents/Resources/"
            relevant = [item for item in members if item.filename.startswith(prefix)]
            if not relevant:
                raise RuntimeError("The macOS update archive doesn't contain an Auto AE app.")
            total_size = 0
            for item in relevant:
                relative_name = item.filename[len(prefix):]
                if not relative_name:
                    continue
                relative = PurePosixPath(relative_name)
                if relative.is_absolute() or any(part in ("", ".", "..") for part in relative.parts):
                    raise RuntimeError("The macOS update archive contains an unsafe file path.")
                total_size += item.file_size
                if total_size > MAX_RELEASE_SIZE:
                    raise RuntimeError("A file in the macOS update archive is too large.")
                target = staging_dir.joinpath(*relative.parts)
                if item.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(item) as source, open(target, "wb") as output:
                    shutil.copyfileobj(source, output)

        app_dir = staging_dir / "app"
        manifest_path = staging_dir / "app-manifest.json"
        requirements_path = staging_dir / "requirements-macos.txt"
        if not app_dir.is_dir() or not manifest_path.is_file() or not requirements_path.is_file():
            raise RuntimeError("The macOS update archive is missing required app files.")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        files = manifest.get("files")
        if not isinstance(files, dict) or not files:
            raise RuntimeError("The macOS update archive has an invalid app manifest.")
        if expected_version is not None and manifest.get("version") != expected_version:
            raise RuntimeError(
                "The macOS app version doesn't match the published release version."
            )
        for relative_name, expected_digest in files.items():
            relative = PurePosixPath(relative_name)
            if relative.is_absolute() or any(part in ("", ".", "..") for part in relative.parts):
                raise RuntimeError("The macOS app manifest contains an unsafe file path.")
            source = app_dir.joinpath(*relative.parts)
            if not source.is_file() or _sha256(source) != expected_digest:
                raise RuntimeError("A file in the macOS update archive failed verification.")

        if previous_dir.exists():
            shutil.rmtree(previous_dir)
        if update_dir.exists():
            os.replace(update_dir, previous_dir)
        try:
            os.replace(staging_dir, update_dir)
        except OSError:
            if previous_dir.exists() and not update_dir.exists():
                os.replace(previous_dir, update_dir)
            raise
        if previous_dir.exists():
            shutil.rmtree(previous_dir)
    except Exception:
        if staging_dir.exists():
            shutil.rmtree(staging_dir)
        raise


def _sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def relaunch_macos_after_exit(bundle_path, process_id=None):
    """Start a detached helper that reopens the app after this process exits."""
    process_id = process_id or os.getpid()
    helper = (
        "import os, subprocess, sys, time\n"
        "pid = int(sys.argv[1])\n"
        "while True:\n"
        "    try:\n"
        "        os.kill(pid, 0)\n"
        "    except ProcessLookupError:\n"
        "        break\n"
        "    except PermissionError:\n"
        "        break\n"
        "    time.sleep(0.5)\n"
        "subprocess.Popen(['/usr/bin/open', sys.argv[2]], start_new_session=True, "
        "stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)\n"
    )
    subprocess.Popen(
        [sys.executable, "-c", helper, str(process_id), str(bundle_path)],
        start_new_session=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        close_fds=True,
    )
